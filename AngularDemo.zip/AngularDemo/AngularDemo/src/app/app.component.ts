import { Component } from "@angular/core";
import { RouterModule, Routes } from '@angular/router';

@Component({
    selector: 'my-app',
    template: `<div style="padding:5px;">
                    <ul class="nav nav-tabs">
                        <li routerLinkActive="active"> <a  routerLink="home">Home</a></li>
                        <li routerLinkActive="active"> <a routerLink="employees">Employees</a></li>                
                    </ul>
                    <router-outlet></router-outlet>
                </div>`
//    template: `Your Text: <input type="text" [(ngModel)]='userText' />
//<br/> <br/>
//<simple [simpleInput]='userText'></simple>`
    //template:`<list-employee></list-employee>`
    //templateUrl: `app/app.component.html`,
    //template: `Name: <input [(ngModel)]='name'/>
    //            <br/>
    //            You Entered: {{name}}`
})

export class AppComponent {
    //userText: string="Vinayak"
    pageHeader: string = "Employee Details";
    //name: string="Vinayak"
    ////imagePath: string = "Images/Logo.JPG";
}




//import { Component } from '@angular/core';

//@Component({
//  selector: 'my-app',
//  template: `<h1>Hello {{name}}</h1>`,
//})
//export class AppComponent  { name: string = 'Angular new'; }
