﻿import { Component, OnInit } from "@angular/core";
import { IEmployee } from "./employee";
import { ActivatedRoute, Router } from "@angular/router";
import { EmployeeService } from "./employee.service";

@Component({
    selector: 'my-employee',
    templateUrl: 'app/employee/employee.component.html',
    styleUrls: ['app/employee/employee.component.css'],

})

export class EmployeeComponent implements OnInit {
    employee: IEmployee;
    statusMessage: string = 'Loading Data Please wait!';
    constructor(private _employeeService: EmployeeService,
                private _activatedRoute: ActivatedRoute,
                private _router: Router) {

    }

    onBackButtonClick(): void {
        this._router.navigate(['/employees']);
    }

    ngOnInit() {
        let empCode: string = this._activatedRoute.snapshot.params['code'];
        this._employeeService.getEmployeesByCode(empCode).subscribe(
            (employeeData) => {

                if (employeeData == null) {
                    this.statusMessage = "Employee does not exist";
                }
                else {
                    this.employee = employeeData
                }

            },
            (error) => {
                this.statusMessage = 'Please try again';
                console.log(error);
            }
        )
    }
    //columnSpan: number = 2;
    //firstname: string = "Vinayak";
    //lastname: string = "Savale";
    //Gender: string = "Male";
    //Age: number = 22;

    //showDetails: boolean = false;

    //toggleDetails(): void {
    //    this.showDetails = !this.showDetails;

}
