﻿import { Injectable } from "@angular/core";
import { IEmployee } from "./employee";
import { Http, Response } from "@angular/http";
import { Observable } from "rxjs/Observable";
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';

@Injectable()
export class EmployeeService {

    constructor(private _http: Http) {

    }

    getEmployees(): Observable<IEmployee[]> {
        return this._http.get("http://localhost:24444/api/employees")
            .map((response: Response) => <IEmployee[]>response.json()).catch(this.handleError)
    }

    getEmployeesByCode(empCode: string): Observable<IEmployee> {
        return this._http.get("http://localhost:24444/api/employees/" + empCode)
            .map((response: Response) => <IEmployee>response.json()).catch(this.handleError)
    }


    handleError(error: Response) {
        console.error(error);
        return Observable.throw(error);
    }
}

//@Injectable()
//export class EmployeeService {
//    getEmployees(): IEmployee[] {
//        return [{ code: 'emp01', name: 'vvs', gender: 'male', annualsalary: 10000, dob: '12/12/1988' },
//            { code: 'emp02', name: 'abc', gender: 'male', annualsalary: 1000, dob: '12/5/2000' },
//            { code: 'emp03', name: 'pqr', gender: 'female', annualsalary: 11000, dob: '11/8/1988' }
//        ];
//    }
//}