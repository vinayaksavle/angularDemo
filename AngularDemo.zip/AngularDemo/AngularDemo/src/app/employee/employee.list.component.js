"use strict";
var EmployeeListComponent = (function () {
    function EmployeeListComponent() {
        this.employee = [
            { code: 'emp01', name: 'vvs', Gender: 'male', AnnualSalary: 10000, dob: '20 May' },
            { code: 'emp02', name: 'abc', Gender: 'male', AnnualSalary: 1000, dob: '20 May' }
        ];
    }
    return EmployeeListComponent;
}());
exports.EmployeeListComponent = EmployeeListComponent;
//# sourceMappingURL=employee.list.component.js.map