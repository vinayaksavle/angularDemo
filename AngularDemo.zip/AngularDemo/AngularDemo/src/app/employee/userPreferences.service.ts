﻿import { Injectable } from "@angular/core";

@Injectable()
export class UserPreferencesService {

    constructor() {
        console.log('New Insatnce of Service created');
    }

    colourPreference: string = 'orange';

}