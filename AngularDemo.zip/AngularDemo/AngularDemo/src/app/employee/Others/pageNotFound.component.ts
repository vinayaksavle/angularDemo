﻿import { Component } from "@angular/core";

@Component({
    template: `<h1>The page you are looking for not exist</h1>`
})

export class PageNotFoundComponent {

}